<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="{{ asset('css/homepage.css') }}">
</head>
<body>
    
    @include('header')

    <div class="home-container">
        <h2>Bienvenue</h2>
        <p>Ceci est un test pour rentrer dans l’entreprise R&MI, qui recrute des esprits curieux et analytiques à travers des énigmes captivantes. Serez-vous à la hauteur ?</p>
        <a href="{{ route('test.start') }}" class="btn btn-primary">LANCER LE TEST</a>
    </div>

</body>
</html>