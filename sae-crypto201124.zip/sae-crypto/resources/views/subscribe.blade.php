<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="{{ asset('css/subscribe.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>

<body>

    @include('header')

    <div class="subscribe-container">
        <div class="subscribe-content">
            <img src="{{ asset('img/img-connexion.png') }}" alt="image du bloc de d'inscription">
            <div class="subscribe-form">
                <form action="{{ route('subscribe') }}" method="POST">
                    <h2><span style="color: #37DD00">Bonjour</span> !</h2>
                    <h2>Bienvenue sur R&MI</h2>
                    <h3>Veuillez vous <span style="color: #37DD00">inscrire</span> !</h3>

                    @csrf
                    <div class="form-group">
                        <label for="username">Nom d'utilisateur</label>
                        <input type="username" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Adresse mail</label>
                        <input type="email" id="mail" name="mail" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Âge</label>
                        <input type="old" id="old" name="old" required>
                    </div>
                    <button type="submit">Inscription</button>
                    <div class="form-group2">
                        <label for="remember">Vous avez déjà un compte ?</label>

                        <a href="{{ route('login') }}" class="se_connecter">Se connecter</a>

                    </div>

                </form>
            </div>
        </div>
    </div>

</body>

</html>
