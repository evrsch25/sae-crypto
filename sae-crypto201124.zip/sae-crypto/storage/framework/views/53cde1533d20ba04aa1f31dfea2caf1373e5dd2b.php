<link rel="stylesheet" href="<?php echo e(asset('css/header.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

<header>
    <div class="header-content1">
        <a href="<?php echo e(route('login')); ?>">
            <img src="<?php echo e(asset('img/profil.png')); ?>" alt="logo profil de connexion">
        </a>
        <p><span style="color: white; font-size: 30px">Alexisdu69</span></p>
    </div>
    <div class="header-content2">
        <img id="settingsIcon" class="parametre" src="<?php echo e(asset('img/parametres.png')); ?>" alt="logo paramètres" onclick="openNav()">
    </div>
</header>

<?php echo $__env->make('sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\erwan\OneDrive\Bureau\Documents\BUT3\SAE-crypto\sae-crypto\resources\views/header.blade.php ENDPATH**/ ?>