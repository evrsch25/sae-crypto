<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>
<body>
    
    @include('header')

    <div class="login-container">
        <div class="login-content">
            <img src="{{ asset('img/img-connexion.png') }}" alt="image du bloc de connexion">
            <div class="login-form">
                <form action="{{ route('login') }}" method="POST">
                    <h2><span style="color: #37DD00">Bonjour</span> !</h2>
                    <h2>Bienvenue sur R&MI</h2>
                    <h3>Veuillez vous <span style="color: #37DD00">connecter</span> !</h3>
            
                    @csrf
                    <div class="form-group">
                        <label for="username">Nom d'utilisateur</label>
                        <input type="username" id="username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <button type="submit">Connexion</button>
                    <div class="form-group2">
                        <label for="remember">Vous n'avez pas de compte ?</label>
                        <button type="submit">Inscription</button>
                    </div>
                    <div class="form-group">
                        <a href="{{ route('password.request') }}">Mot de passe oublié ?</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>