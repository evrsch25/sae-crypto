<link rel="stylesheet" href="{{ asset('css/sidenav.css') }}">
<link rel="stylesheet" href="{{ asset('css/app.css') }}">

<div id="mySidenav" class="sidenav">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <a href="#">Mentions légales</a>
    <a href="#">Politique de confidentialité</a>
    <a href="#">Conditions générales d'utilisation</a>
    <div class="langue">
        <p>Langue</p>
        <a href="#" class="active">Français</a>
        <a href="#">English</a>
    </div>
    <div class="mode-switch">
        <label class="switch">
            <input type="checkbox" id="modeToggle" onclick="toggleMode()">
            <span class="slider round">
                <img src="{{ asset('img/mode-nuit.png') }}" class="night-icon">
                <img src="{{ asset('img/mode-jour.png') }}" class="day-icon">
            </span>
        </label>
    </div>
</div>

<script src="{{ asset('js/sidenav.js') }}"></script>