<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="login-container">
        <div class="login-content">
            <img src="<?php echo e(asset('img/img-connexion.png')); ?>" alt="image du bloc de connexion">
            <div class="login-form">
                <form action="<?php echo e(route('login')); ?>" method="POST">
                    <h2><span style="color: #37DD00">Bonjour</span> !</h2>
                    <h2>Bienvenue sur R&MI</h2>
                    <h3>Veuillez vous <span style="color: #37DD00">connecter</span> !</h3>

                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="username">Nom d'utilisateur</label>
                        <input type="username" id="username" name="username">
                    </div>
                    <div class="form-group">
                        <label for="password">Mot de passe</label>
                        <input type="password" id="password" name="password">
                    </div>

                    <div class="mdp">
                        <a href="<?php echo e(route('password.request')); ?>" id="mdp">Mot de passe oublié ?</a>
                    </div>

                    <button type="submit">Connexion</button>


                    <div class="form-group2">
                        <label for="remember">Vous n'avez pas de compte ?</label>
                        <a href="<?php echo e(route('subscribe')); ?>" class="btn-inscription">Inscription</a>
                    </div>

                </form>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\Users\erwan\OneDrive\Bureau\Documents\BUT3\SAE-crypto\sae-crypto\resources\views/login.blade.php ENDPATH**/ ?>