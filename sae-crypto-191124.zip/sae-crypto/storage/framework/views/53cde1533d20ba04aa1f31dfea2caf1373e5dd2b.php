<link rel="stylesheet" href="<?php echo e(asset('css/header.css')); ?>">

<header>
    <div class="header-content1">
        <a href="<?php echo e(route('login')); ?>">
            <img src="<?php echo e(asset('img/profil.png')); ?>" alt="logo profil de connexion">
        </a>
        <p>Alexisdu69</p>
    </div>
    <div class="header-content2">
        <img src="<?php echo e(asset('img/parametres.png')); ?>" alt="logo paramètres">
    </div>
</header><?php /**PATH C:\Users\erwan\OneDrive\Bureau\Documents\BUT3\SAE-crypto\sae-crypto\resources\views/header.blade.php ENDPATH**/ ?>