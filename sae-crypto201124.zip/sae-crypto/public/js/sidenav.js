function openNav() {
    document.getElementById("mySidenav").style.width = "30%";
    document.getElementById("settingsIcon").classList.add("hidden");
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("settingsIcon").classList.remove("hidden");
}

function toggleMode() {
    var element = document.body;
    element.classList.toggle("white-mode");
    var modeToggle = document.getElementById("modeToggle");
    if (element.classList.contains("white-mode")) {
        localStorage.setItem("mode", "white-mode");
        modeToggle.checked = true;
    } else {
        localStorage.removeItem("mode");
        modeToggle.checked = false;
    }
}

document.addEventListener("DOMContentLoaded", function() {
    var modeToggle = document.getElementById("modeToggle");
    if (localStorage.getItem("mode") === "white-mode") {
        document.body.classList.add("white-mode");
        modeToggle.checked = true;
    } else {
        modeToggle.checked = false;
    }
});