<link rel="stylesheet" href="{{ asset('css/header.css') }}">

<header>
    <div class="header-content1">
        <a href="{{ route('login') }}">
            <img src="{{ asset('img/profil.png') }}" alt="logo profil de connexion">
        </a>
        <p>Alexisdu69</p>
    </div>
    <div class="header-content2">
        <img src="{{ asset('img/parametres.png') }}" alt="logo paramètres">
    </div>
</header>