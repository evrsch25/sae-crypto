<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/homepage.css')); ?>">
</head>
<body>
    
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="home-container">
        <h2>Bienvenue</h2>
        <p>Ceci est un test pour rentrer dans l’entreprise R&MI, qui recrute des esprits curieux et analytiques à travers des énigmes captivantes. Serez-vous à la hauteur ?</p>
        <a href="<?php echo e(route('test.start')); ?>" class="btn btn-primary">LANCER LE TEST</a>
    </div>

</body>
</html><?php /**PATH C:\Users\erwan\OneDrive\Bureau\Documents\BUT3\SAE-crypto\sae-crypto\resources\views/homepage.blade.php ENDPATH**/ ?>