<link rel="stylesheet" href="{{ asset('css/header.css') }}">
<link rel="stylesheet" href="{{ asset('css/app.css') }}">

<header>
    <div class="header-content1">
        <a href="{{ route('login') }}">
            <img src="{{ asset('img/profil.png') }}" alt="logo profil de connexion">
        </a>
        <p><span style="color: white; font-size: 30px">Alexisdu69</span></p>
    </div>
    <div class="header-content2">
        <img id="settingsIcon" class="parametre" src="{{ asset('img/parametres.png') }}" alt="logo paramètres" onclick="openNav()">
    </div>
</header>

@include('sidenav')